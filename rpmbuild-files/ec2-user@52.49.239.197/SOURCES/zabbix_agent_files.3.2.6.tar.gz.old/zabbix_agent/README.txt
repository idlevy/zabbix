usr
zabbix_agent   put under/ etc/init.d 
zabbix_agentd  put under installation path ( /usr/sbin . originaly it  is under /usr/local/sbin/ )
zabbox-agent.conf - originaly under /usr/local/etc/
2 more zabbix files - under /usr/local/bin/



