test examples:

zabbix_get -s localhost -k 'zkok[]'
zabbix_get -s localhost -k 'zkok[]'
zabbix_get -s localhost -k 'zkstats[zk_max_latency]'
zabbix_get -s localhost -k 'zkstats[zk_max_latency]'
zabbix_get -s localhost -k 'zkstats[zk_max_latency]'
