need to:
 put elasticsearch_metrics.py in /usr/bin/
ESzabbix.conf in /usr/local/etc/zabbix_agent.d/

update zabbix_agentd.conf (/usr/local/etc/) update changes  in the  rpm.


